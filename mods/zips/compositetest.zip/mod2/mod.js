new class {
    id = "mod2";
    name = "mod2";
    chatName = "Mod2";
    version = 2;

    onGameStart = (game) => {
    };

    onWorldStart = (game) => {
        game.displayChat("Mod 2 - Test!");
    };
}
new class {
    id = "mod1";
    name = "mod1";
    chatName = "Mod1";
    version = 2;

    onGameStart = (game) => {
    };

    onWorldStart = (game) => {
        game.displayChat("Mod 1 - Test!");
    };
}